const EVMRevert = 'revert';

module.exports = {
  EVMRevert,
};
